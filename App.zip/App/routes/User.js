//import express
const express = require('express')

//get the express router
// - router: used for routing
const router = express.Router()
const db = require('../db')
//import crypto-js for encrypting the password
const cryptoJs = require('crypto-js')


//user related API's
router.post ('/signup', (request, response) => {
    //get the body parameters
    //console.log(request.body)

    //extracting the keys from request body
    //all the matching keys are extracted as variables
    //FName, LName, email, password are now keys
    const {FName, LName, email,password } = request.body
    

    const encryptedPassword =''+ cryptoJs.MD5(password)

    const query = ('insert into user (FName, LName, email, password) values(?,?,?,?)')
    const params = [FName, LName, email, encryptedPassword]
    db.execute(query,params,(error,result) => {
        if(error){
            console.log(error)
        }
        else{
            console.log(result)
        }
        response.send('done')
    })
})

router.post ('/signin', (request, response) => {
    const {email,password}=request.body

    //encrypt the password
    const encryptedPassword =''+ cryptoJs.MD5(password)
    const query = `select * from user where email = ? and password =? `
    const params = [email,password]

    db.execute(query,params,(error,users) => {
        if(error){
            console.log(error)
            response.send('error')
        }
        else{
            console.log(users)
            if(users.length ==0){
                response.send('user does not exist')
            }
            else{
                response.send(users[0])
            }
            
        }
    })
})

router.get ('/profile', (request, response) => {
    console.log('user is returning profile')
    response.send()
})

router.put ('/profile', (request, response) => {
    console.log('updating user profile')
    response.send()
})

//export router and use it in server.js
module.exports = router