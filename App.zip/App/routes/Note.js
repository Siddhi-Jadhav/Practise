//import express
const express = require('express')

//get the express router
//Routing refers to determining how an application responds to a client request to a particular endpoint, 
//which is a URL (or path) and a specific HTTP request
// - router: used for routing
const router = express.Router()

//Note's related API's
router.get ('/all', (request, response) => {
    console.log('Returning all notes')
    response.send()
})

router.get ('/my', (request, response) => {
    console.log('Returning my notes')
    response.send()
})

router.post ('/', (request, response) => {
    console.log('creating new note')
    response.send()
})

router.put ('/:id', (request, response) => {
    console.log('updating a note')
    response.send()
})

router.delete ('/:id', (request, response) => {
    console.log('deleting a note')
    response.send()
})

//export router and use it in server.js
module.exports = router