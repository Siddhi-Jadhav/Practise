//import express
const express = require('express')

//create express app
const app = express()

//allow user to send data
//used to read the data from request body
//and convert it into JS object
app.use(express.json())

const routerUser = require('./routes/User')
const routerNotes = require('./routes/Note')
//add the routes
app.use('/user',routerUser)
app.use('/note',routerNotes)

//start app
app.listen(4000,'0.0.0.0', () => {
    console.log('Server started on 4000')
})