#sample rest application

-features
 - user
    - POST /user/signup
    - POST /user/signin
    - GET /user/profile
    - PUT /user/profile

 - note
    - GET /note/all
    - GET /note/my
    - POST /note/
    - PUT /note/<id>
    - DELETE /note/<id>