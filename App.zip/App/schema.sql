create DATABASE express_db;
use express_db;
create TABLE User (
    id INT PRIMARY KEY auto_increment,
    FName VARCHAR(20),
    LName VARCHAR(20),
    email VARCHAR(45),
    PASSWORD VARCHAR(45)
);

CREATE TABLE Note(
    id INT PRIMARY KEY auto_increment,
    Title VARCHAR(20),
    UserId integer,
    contents VARCHAR(1024)
);