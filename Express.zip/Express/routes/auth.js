const express = require('express')

const router = express.Router()

router.post('/signup', (request,response) => {
    console.log('user sign up')
    response.send()
})

router.post('/signin', (request,response) => {
    console.log('user sign in')
    response.send()
})

module.exports = router