const express = require('express')

// get the express router
// -router used for routing
const router = express.Router()

router.get('/', (request,response) => {
    console.log('get all tasks including filters')
    response.send()
})

router.get('/:id', (request,response) => {
    console.log('get a task details')
    response.send()
})

router.post('/', (request,response) => {
    console.log('create a task')
    response.send()
})

router.delete('/:id', (request,response) => {
    console.log('delete a task')
    response.send()
})

router.patch('/:id/status', (request,response) => {
    console.log('update a task')
    response.send()
})

// export router and use it in server.js
module.exports = router
