//import express
const express = require('express')

//create express app
const app = express()

//create routes
const routerTask = require('./routes/task')
const routerUser = require('./routes/auth')

// add routes
app.use('/task' ,routerTask)
app.use('/auth' ,routerUser)

//start app
app.listen(4000, '0.0.0.0', () => {
    console.log('server started on port 4000')

})