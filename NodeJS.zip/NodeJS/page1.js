//import file system package
//Common use for the File System module:Read files,Create files,Update files,Delete files,Rename files
const fs = require('fs')
//Sequential
function synchronousFunction(){
    //read file synchronously
    console.log("Reading file started")
    const data = fs.readFileSync('./file.txt')
    //console.log('' + data)
    console.log("Reading file finished")

    console.log('Math Operation started')
    const num1 = 5434243523
    const num2 = 5426435467
    console.log(`${num1} * ${num2} = ${num1 * num2} `)
    console.log('Math Operation Finished')

}
//synchronousFunction()


//non-sequential
//Asynchronous
function asynchronousFunction(){
    console.log("Reading file started")
    fs.readFile('./file.txt', (error, data) =>{
        console.log("Reading file finished")
        //console.log('' + data)
    })

    console.log('Math Operation started')
    const num1 = 5434243523
    const num2 = 5426435467
    console.log(`${num1} * ${num2} = ${num1 * num2} `)
    console.log('Math Operation Finished')

}
asynchronousFunction()