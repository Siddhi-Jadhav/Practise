//import http to create web server
const http = require('http')
//create http server
const server = http.createServer((request,response) => {
    console.log(`Received a request`)
    //processing is finished
    //send the current state of response to the client
    response.end('hi, this is a server')
})

//start the server
server.listen(4000,'0.0.0.0',() => {
    console.log(`server started on port 4000`)
})