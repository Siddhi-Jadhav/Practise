//import express
const express = require('express')
//create an express application
const app = express()

//route collection
// - mapping of http method and url
app.get('/', (request,response) => {
    console.log('GET /')
    response.end()
})


//start the application
app.listen(4000,'0.0.0.0', () =>{
    console.log('Server started on port 4000');
})