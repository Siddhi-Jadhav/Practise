//import http to create web server
const http = require('http')
//create http server
const server = http.createServer((request,response) => {
    console.log(`method = ${request.method}`)
    console.log(`path = ${request.url}`)
    
    if(request.method == 'GET'){
        if(request.url == '/person')
        console.log('select * from person')
        else if(request.url == '/product')
        console.log('select * from product')
        console.log('Hello')
    }
    else if(request.method == 'POST'){
        if(request.url == '/person')
        console.log('insert into person')
        else if(request.url == '/product')
        console.log('insert into product')
    }
    else if(request.method == 'PUT'){
        if(request.url == '/person')
        console.log('update person')
        else if(request.url == '/product')
        console.log('update product')
    }
    else if(request.method == 'DELETE'){
        if(request.url == '/person')
        console.log('Delete from person')
        else if(request.url == '/product')
        console.log('Delete from product')
    }
    
    response.end('hi, this is a server')
})

//start the server
server.listen(4000,'0.0.0.0',() => {
    console.log(`server started on port 4000`)
})