const fs = require('fs')
function synchronousFunction(){
    //read file synchronously
    try {
        console.log("Reading file started")
        const data = fs.readFileSync('./file12.txt')
        //console.log('' + data)
        console.log("Reading file finished")
    }
    catch (ex) {
        console.log(`Exception ocurred :  `,ex)
    }

    console.log('Math Operation started')
    const num1 = 5434243523
    const num2 = 5426435467
    console.log(`${num1} * ${num2} = ${num1 * num2} `)
    console.log('Math Operation Finished')

}
//synchronousFunction()


function asynchronousFunction(){
    //read file synchronously
    console.log("Reading file started")
    fs.readFile('./file.txt', (error, data) =>{
        console.log("Reading file finished")
        if(error){
            console.log(`error ocurred while reading the file`)
            console.log(error)
        }
        else{
            console.log('' + data)
        }
    })
}
asynchronousFunction()